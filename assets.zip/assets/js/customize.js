// $(window).load(function() {
//     // Animate loader off screen
//     $(".page-loading-wrapper").fadeOut("slow");;
// });

jQuery(function($){
    // init controller
    // var controller = new ScrollMagic.Controller();
    // // create a scene
    // new ScrollMagic.Scene({
    //     duration: 100,  // the scene should last for a scroll distance of 100px
    //     offset: 30  // start this scene after scrolling for 50px
    // })
    // .setPin("#my-sticky-element") // pins the element for the the scene's duration
    // .addTo(controller); // assign the scene to the controller

    $('.js-tilt').tilt({
        axis: 'x'
    });   
    new WOW().init();
    $(window).scroll(function() {
        var e = $(window).scrollTop();
        e >= 30 ? $("header.md-header").addClass("fixed") : $("header.md-header").removeClass("fixed"); 
    }).scroll();

    // HOME PAGE SLIDER START
    $('.homeSlider').slick({
        dots:true,
        arrows:false,
        infinite: false,
        autoplay:false,
        // autoplaySpeed: 5000,
        // speed: 2500,
        draggable:true,
        lazyLoad: 'ondemand',
    }).slickAnimation();
    $('.homeSlider .slick-dots').wrap('<div class="slider-bullets-wrapper"><div class="container"></div></div>');
    let heroSlideCount = $('.hero-slide-count-wrap').remove();
    heroSlideCount.appendTo('.slider-bullets-wrapper');
    // HOME PAGE SLIDER END

    $('.homeCategorySlider').slick({
        dots:false,
        arrows:true,
        centerMode: true,
        infinite: true,
        autoplay:false,
        draggable:true,
        slidesToShow: 3,
        slidesToScroll: 1,
    }).slickAnimation();

    // Product Slider
    $('.productSlider').slick({
        dots:false,
        arrows:true,
        infinite: false,
        autoplay:true,
        // draggable:true,
        slidesToShow: 3,
        slidesToScroll: 1
    }).slickAnimation();

    $('.slider-content-for').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        infinite: false,
        draggable:false,
        arrows: false,
        fade: true,
        asNavFor: '.slider-logo-nav'
    });
    $('.slider-logo-nav').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        asNavFor: '.slider-content-for',
        dots: false,
        centerMode: true,
        focusOnSelect: true,
        arrows:false
    });
    
    $('.scrolldown_md[href^="#"]').on("click", function(e) {
        e.preventDefault();
        var a = $(this.hash).offset() ? $(this.hash).offset().top : 0;
        $("html, body").animate({
            scrollTop: a - 65
        }, 500);
    });
});

function openmodalpop(e, a) {
    var t = $(e),
        s = t.offset() ? t.offset().left : 0,
        i = (t.offset() ? t.offset().top : 0) - $(document).scrollTop();
    $("#" + a).css({
        top: i,
        left: s
    }), t.click(function() {
        $("#" + a).addClass("open"); 
        $("body").addClass("oh");
    });
}

function colsemodalpop(e) {
    $("#" + e).hasClass("open"); 
    $("#" + e).removeClass("open"); 
    $("body").removeClass("oh");
}
